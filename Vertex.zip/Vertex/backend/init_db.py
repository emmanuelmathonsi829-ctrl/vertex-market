import os
import psycopg
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    raise ValueError("DATABASE_URL is missing from your .env file.")

schema = """
CREATE TABLE IF NOT EXISTS users_ (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categories_ (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products_ (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users_(id) ON DELETE CASCADE,
    category_id BIGINT REFERENCES categories_(id) ON DELETE SET NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    price NUMERIC(12, 2) NOT NULL CHECK (price >= 0),
    image_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS likes_ (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users_(id) ON DELETE CASCADE,
    product_id BIGINT NOT NULL REFERENCES products_(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, product_id)
);

CREATE TABLE IF NOT EXISTS product_views_ (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users_(id) ON DELETE CASCADE,
    product_id BIGINT NOT NULL REFERENCES products_(id) ON DELETE CASCADE,
    viewed_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, product_id)
);

CREATE TABLE IF NOT EXISTS cart_items_ (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users_(id) ON DELETE CASCADE,
    product_id BIGINT NOT NULL REFERENCES products_(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
    added_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, product_id)
);

CREATE INDEX IF NOT EXISTS idx_products_category_
    ON products_(category_id);

CREATE INDEX IF NOT EXISTS idx_products_user_
    ON products_(user_id);

CREATE INDEX IF NOT EXISTS idx_likes_user_
    ON likes_(user_id);

CREATE INDEX IF NOT EXISTS idx_product_views_user_
    ON product_views_(user_id);

CREATE INDEX IF NOT EXISTS idx_cart_items_user_
    ON cart_items_(user_id);

INSERT INTO categories_ (name)
VALUES
    ('Sneakers'),
    ('Tech'),
    ('Lifestyle'),
    ('Food'),
    ('Clothes'),
    ('Uncategorised')
ON CONFLICT (name) DO NOTHING;
"""

with psycopg.connect(DATABASE_URL, sslmode="require") as connection:
    with connection.cursor() as cursor:
        cursor.execute(schema)

print("Vortex Market database tables created successfully!")