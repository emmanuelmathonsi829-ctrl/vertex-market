from psycopg.rows import dict_row
from database import get_connection


class Category:

    @staticmethod
    def get_all():
        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    SELECT id, name, created_at
                    FROM categories_
                    ORDER BY name ASC
                    """
                )

                return cursor.fetchall()

    @staticmethod
    def get_by_id(category_id):
        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    SELECT id, name, created_at
                    FROM categories_
                    WHERE id = %s
                    """,
                    (category_id,)
                )

                return cursor.fetchone()

    @staticmethod
    def create(name):
        name = name.strip()

        if not name:
            raise ValueError("Category name cannot be empty.")

        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    INSERT INTO categories_ (name)
                    VALUES (%s)
                    ON CONFLICT (name) DO NOTHING
                    RETURNING id, name, created_at
                    """,
                    (name,)
                )

                category = cursor.fetchone()

                if category is not None:
                    return category

                cursor.execute(
                    """
                    SELECT id, name, created_at
                    FROM categories_
                    WHERE name = %s
                    """,
                    (name,)
                )

                return cursor.fetchone()