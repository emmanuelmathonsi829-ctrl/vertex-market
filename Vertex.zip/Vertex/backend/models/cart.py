from psycopg.rows import dict_row
from database import get_connection


class Cart:

    @staticmethod
    def add_item(user_id, product_id, quantity=1):
        if quantity < 1:
            raise ValueError("Quantity must be at least 1.")

        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    INSERT INTO cart_items_ (user_id, product_id, quantity)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (user_id, product_id)
                    DO UPDATE SET quantity = cart_items_.quantity + EXCLUDED.quantity
                    RETURNING id, user_id, product_id, quantity, added_at
                    """,
                    (user_id, product_id, quantity)
                )

                return cursor.fetchone()

    @staticmethod
    def get_items(user_id):
        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    SELECT
                        ci.id,
                        ci.product_id,
                        ci.quantity,
                        ci.added_at,
                        p.title,
                        p.price,
                        p.image_url,
                        p.user_id AS seller_id
                    FROM cart_items_ ci
                    JOIN products_ p ON p.id = ci.product_id
                    WHERE ci.user_id = %s
                    ORDER BY ci.added_at DESC
                    """,
                    (user_id,)
                )

                return cursor.fetchall()

    @staticmethod
    def update_quantity(user_id, product_id, quantity):
        if quantity < 1:
            raise ValueError("Quantity must be at least 1.")

        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    UPDATE cart_items_
                    SET quantity = %s
                    WHERE user_id = %s AND product_id = %s
                    RETURNING id, user_id, product_id, quantity, added_at
                    """,
                    (quantity, user_id, product_id)
                )

                return cursor.fetchone()

    @staticmethod
    def remove_item(user_id, product_id):
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    DELETE FROM cart_items_
                    WHERE user_id = %s AND product_id = %s
                    """,
                    (user_id, product_id)
                )

                return cursor.rowcount > 0

    @staticmethod
    def clear(user_id):
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    DELETE FROM cart_items_
                    WHERE user_id = %s
                    """,
                    (user_id,)
                )

                return cursor.rowcount