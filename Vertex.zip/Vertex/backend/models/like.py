
from psycopg.rows import dict_row
from database import get_connection


class Like:

    @staticmethod
    def add(user_id, product_id):
        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    INSERT INTO likes_ (user_id, product_id)
                    VALUES (%s, %s)
                    ON CONFLICT (user_id, product_id) DO NOTHING
                    RETURNING id, user_id, product_id, created_at
                    """,
                    (user_id, product_id)
                )

                return cursor.fetchone()

    @staticmethod
    def remove(user_id, product_id):
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    DELETE FROM likes_
                    WHERE user_id = %s AND product_id = %s
                    """,
                    (user_id, product_id)
                )

                return cursor.rowcount > 0

    @staticmethod
    def get_user_likes(user_id):
        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    SELECT
                        p.id,
                        p.title,
                        p.description,
                        p.price,
                        p.image_url,
                        p.category_id,
                        l.created_at AS liked_at
                    FROM likes_ l
                    JOIN products_ p ON p.id = l.product_id
                    WHERE l.user_id = %s
                    ORDER BY l.created_at DESC
                    """,
                    (user_id,)
                )

                return cursor.fetchall()

    @staticmethod
    def has_liked(user_id, product_id):
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT 1
                    FROM likes_
                    WHERE user_id = %s AND product_id = %s
                    """,
                    (user_id, product_id)
                )

                return cursor.fetchone() is not None

