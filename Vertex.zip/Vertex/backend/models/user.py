from werkzeug.security import generate_password_hash, check_password_hash
from psycopg.rows import dict_row
from database import get_connection


class User:

    @staticmethod
    def create(full_name, email, password):
        password_hash = generate_password_hash(password)

        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    INSERT INTO users_ (full_name, email, password_hash)
                    VALUES (%s, %s, %s)
                    RETURNING id, full_name, email, created_at
                    """,
                    (full_name, email.strip().lower(), password_hash)
                )

                return cursor.fetchone()

    @staticmethod
    def get_by_email(email):
        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    SELECT id, full_name, email, password_hash, created_at
                    FROM users_
                    WHERE email = %s
                    """,
                    (email.strip().lower(),)
                )

                return cursor.fetchone()

    @staticmethod
    def verify_password(email, password):
        user = User.get_by_email(email)

        if user is None:
            return None

        if check_password_hash(user["password_hash"], password):
            user.pop("password_hash")
            return user

        return None