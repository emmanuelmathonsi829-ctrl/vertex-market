
from psycopg.rows import dict_row
from database import get_connection


class Product:

    @staticmethod
    def create(user_id, title, description, price, category_id=None, image_url=None):
        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    INSERT INTO products_ (
                        user_id,
                        category_id,
                        title,
                        description,
                        price,
                        image_url
                    )
                    VALUES (%s, %s, %s, %s, %s, %s)
                    RETURNING *
                    """,
                    (
                        user_id,
                        category_id,
                        title.strip(),
                        description.strip(),
                        price,
                        image_url
                    )
                )

                return cursor.fetchone()

    @staticmethod
    def get_by_id(product_id):
        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    SELECT
                        p.id,
                        p.user_id,
                        p.category_id,
                        p.title,
                        p.description,
                        p.price,
                        p.image_url,
                        p.created_at,
                        u.full_name AS seller_name,
                        c.name AS category_name
                    FROM products_ p
                    JOIN users_ u ON u.id = p.user_id
                    LEFT JOIN categories_ c ON c.id = p.category_id
                    WHERE p.id = %s
                    """,
                    (product_id,)
                )

                return cursor.fetchone()

    @staticmethod
    def get_random_batch(limit=8, exclude_ids=None):
        exclude_ids = exclude_ids or []
        limit = max(1, min(int(limit), 50))

        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    SELECT
                        p.id,
                        p.user_id,
                        p.category_id,
                        p.title,
                        p.description,
                        p.price,
                        p.image_url,
                        p.created_at,
                        u.full_name AS seller_name,
                        c.name AS category_name
                    FROM products_ p
                    JOIN users_ u ON u.id = p.user_id
                    LEFT JOIN categories_ c ON c.id = p.category_id
                    WHERE NOT (p.id = ANY(%s))
                    ORDER BY RANDOM()
                    LIMIT %s
                    """,
                    (exclude_ids, limit)
                )

                return cursor.fetchall()

    @staticmethod
    def get_by_category(category_id, limit=50):
        limit = max(1, min(int(limit), 100))

        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    SELECT
                        p.id,
                        p.user_id,
                        p.category_id,
                        p.title,
                        p.description,
                        p.price,
                        p.image_url,
                        p.created_at,
                        u.full_name AS seller_name,
                        c.name AS category_name
                    FROM products_ p
                    JOIN users_ u ON u.id = p.user_id
                    LEFT JOIN categories_ c ON c.id = p.category_id
                    WHERE p.category_id = %s
                    ORDER BY p.created_at DESC
                    LIMIT %s
                    """,
                    (category_id, limit)
                )

                return cursor.fetchall()

