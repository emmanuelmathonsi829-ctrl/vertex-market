
from psycopg.rows import dict_row
from database import get_connection


class ProductView:

    @staticmethod
    def record_view(user_id, product_id):
        with get_connection() as connection:
            with connection.cursor(row_factory=dict_row) as cursor:
                cursor.execute(
                    """
                    INSERT INTO product_views_ (user_id, product_id)
                    VALUES (%s, %s)
                    ON CONFLICT (user_id, product_id)
                    DO UPDATE SET viewed_at = CURRENT_TIMESTAMP
                    RETURNING id, user_id, product_id, viewed_at
                    """,
                    (user_id, product_id)
                )

                return cursor.fetchone()

    @staticmethod
    def get_viewed_product_ids(user_id):
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT product_id
                    FROM product_views_
                    WHERE user_id = %s
                    ORDER BY viewed_at DESC
                    """,
                    (user_id,)
                )

                return [row[0] for row in cursor.fetchall()]

    @staticmethod
    def has_viewed(user_id, product_id):
        with get_connection() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT 1
                    FROM product_views_
                    WHERE user_id = %s AND product_id = %s
                    """,
                    (user_id, product_id)
                )

                return cursor.fetchone() is not None

